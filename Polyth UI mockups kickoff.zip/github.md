repo: otto-assistant/polyth
branch: master
path: apps/web

## Last sync
date: 2026-08-18T06:31:21Z

### Updated in this project
- Built clickable UI prototype for Polyth: workspace shell/nav, Session Goals, Multi-Run, Model Fusion, Guided Changes Walkthrough, Live Preview + Inspector, Git & Worktree manager, Terminal panel.
- Visual language (colors, spacing, type) lifted directly from apps/web/src/styles.css.

## Screen map
| Screen | Repo source |
|---|---|
| Sidebar / shell / nav | apps/web/src/components/Sidebar.tsx, Header.tsx, Main.tsx, styles.css |
| Session Goals | apps/web/src/components/GoalStrip.tsx, docs/PLAN.md (GoalState) |
| Git & Worktree manager | apps/web/src/components/ChangesPanel.tsx, docs/PLAN.md (M2 git/worktree API) |
| Multi-Run, Fusion, Walkthrough, Preview, Terminal | net-new (M3 roadmap in docs/PLAN.md, not yet built in repo) |
